package Car_factory_pattern;

public class Main {
public static void main(String args[]){
    Factory_selector s= new Factory_selector();
    CarSelector car=s.getInstance("40L");
    car.show();
    car.display();

}

}
