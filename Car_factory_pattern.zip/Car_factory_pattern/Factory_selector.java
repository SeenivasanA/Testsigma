package Car_factory_pattern;

public class Factory_selector {
    public CarSelector getInstance(String a){
    if(a.equals("50L")){
        return new Bmw();
    } else if (a.equals("japan")) {
        return new Toyato();
    }
    else{
        return new Ford();
    }
    }
}
