package Car_factory_pattern;

public interface CarSelector {
    void show();
    void display();
}
