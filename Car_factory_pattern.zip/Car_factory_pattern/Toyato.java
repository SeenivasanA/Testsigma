package Car_factory_pattern;

public class Toyato implements CarSelector{
    @Override
    public void show() {
        System.out.println("oyota Motor Corporation is a Japanese multinational automotive manufacturer headquartered in Toyota City, Aichi, Japan.");
    }

    @Override
    public void display() {
        System.out.println("the cost is 40L");
    }
}
