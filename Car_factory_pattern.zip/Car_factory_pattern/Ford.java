package Car_factory_pattern;

public class Ford implements CarSelector{
    @Override
    public void show() {
        System.out.println("Ford Motor Company (commonly known as Ford) is an American multinational automobile manufacturer headquartered in Dearborn, Michigan, United States. ");
    }

    @Override
    public void display() {
        System.out.println("the cost is 30L");
    }
}
