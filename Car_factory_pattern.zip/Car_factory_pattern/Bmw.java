package Car_factory_pattern;

public class Bmw implements CarSelector{
    @Override
    public void show() {
        System.out.println("Bayerische Motoren Werke AG, commonly referred to as BMW is a German multinational corporate manufacturer of luxury vehicles");
    }

    @Override
    public void display() {
        System.out.println("cost of the car is : 50L");
    }
}
